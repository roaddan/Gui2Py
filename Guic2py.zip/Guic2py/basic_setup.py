from distutils.core import setup
import py2exe
 
setup(
    windows = ['main.py','CodefenInfos.py','fenInfos.py','Guic2Py_dialog1.py','pyutils.py'],
    options = {
        "py2exe" : {
            "includes" : ['sys', 'tempfile', 'zipfile', 'mmap', 'encodings',
                          'json', 'hashlib', 'datetime', 'struct',
                          'os', 'time', 'random', 'math', 'xmlrpclib', 'Crypto']
        }
    }
)

